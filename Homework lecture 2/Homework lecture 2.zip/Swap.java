package vratsasoftware;

public class Swap {
    public static void main(String[] args) {
        int a = 5;
        int b = 11;

        a = 11;
        System.out.println("a = " + a);

        b = 5;
        System.out.println("b = " + b);

    }
}
