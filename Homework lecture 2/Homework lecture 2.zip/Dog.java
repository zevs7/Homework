package vratsasoftware;

public class Dog {
    public static void main(String[] args){
        String name = "Goshko";
        String breed = "Bulterier";
        int ageOFDog = 11;
        int ageOfHuman = 26;
        String nameOfOwner = "Yoan";
        String sex = "male";
        String color = "blue";
        String specialFeatures = "big nose";
        String partners = "many partners";
        int numberOfChildren = 3;
        String nameOfChildren = "Божка, Божена, Божидар";

        // 3 и 4 задача
        System.out.println("-------------------------------------------");
        System.out.println("Куче: "+ name +" " +breed+ " " + color+ " " + sex+" " + ageOFDog );
        System.out.println("Особености: " + specialFeatures);
        System.out.println("Партньори: " + partners );
        System.out.println("Имена на децата на кучето: " + nameOfChildren);
        System.out.println("Име на собственика: " + nameOfOwner);
        System.out.println("Години на собственика: " + ageOfHuman );
        System.out.println("Брой на на децата на кучето: " + numberOfChildren);
        System.out.println("--------------------------------------------");
    }
}
