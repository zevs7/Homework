package vratsasoftware;

public class Triagle {
    public static void main(String[] args) {
        System.out.println("     © ");
        System.out.println("  ©     ©");
        System.out.println("©   ©      ©");
    }
}